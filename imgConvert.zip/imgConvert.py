import os
import pandas as pd
import numpy as np
import cv2

#training code

# Define dataset path and output CSV file
dataset_path = "dataset"
output_csv = "emotion_dataset.csv"

# Define emotion labels based on folder names
emotions = ["Angry", "Disgust", "Fear", "Happy", "Neutral", "Sad", "Surprised"]

# Initialize list to store image data
data = []

# Process each emotion category
for emotion in emotions:
    emotion_path = os.path.join(dataset_path, emotion)
    if not os.path.exists(emotion_path):
        print(f"Skipping {emotion} (folder not found).")
        continue
    
    print(f"Processing images in {emotion}...")

    for img_name in os.listdir(emotion_path):
        img_path = os.path.join(emotion_path, img_name)
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)  # Read as grayscale
        if img is None:
            print(f"Skipping {img_name} (cannot read).")
            continue

        # Skip resizing since images are already 48x48
        img_flattened = img.flatten()  # Convert to 1D array
        data.append([emotion] + img_flattened.tolist())  # Store emotion label & pixel values

# Create a DataFrame
columns = ["emotion"] + [f"pixel{i}" for i in range(48 * 48)]
df = pd.DataFrame(data, columns=columns)

# Save as CSV
df.to_csv(output_csv, index=False)
print(f"Dataset saved as {output_csv}")
