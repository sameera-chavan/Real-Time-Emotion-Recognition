import cv2
import numpy as np
import tensorflow as tf
from mtcnn import MTCNN
import time
import matplotlib.pyplot as plt
from collections import Counter

# Load pre-trained emotion detection model
print("Loading emotion detection model...")
model = tf.keras.models.load_model('emotion_model.h5')
print("Model loaded successfully.")

# Define emotion labels
emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Neutral', 'Sad', 'Surprised']

# Initialize MTCNN detector
print("Initializing MTCNN detector...")
detector = MTCNN()
print("MTCNN initialized.")

def detect_emotion(frame):
    print("Detecting faces...")
    faces = detector.detect_faces(frame)
    if faces:
        print("Face detected.")
        x, y, w, h = faces[0]['box']
        face = frame[y:y+h, x:x+w]
        face = cv2.resize(face, (48, 48))
        face = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
        face = face.astype('float32') / 255.0
        face = np.expand_dims(face, axis=0)
        face = np.expand_dims(face, axis=-1)
        print("Predicting emotion...")
        prediction = model.predict(face)
        emotion = emotion_labels[np.argmax(prediction)]
        print(f"Detected emotion: {emotion}")
        return emotion, (x, y, w, h)
    print("No face detected.")
    return None, None

def main():
    print("Starting video capture...")
    cap = cv2.VideoCapture(0)
    emotion_history = []
    
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture frame.")
            break
        
        emotion, bbox = detect_emotion(frame)
        if emotion:
            x, y, w, h = bbox
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv2.putText(frame, emotion, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)
            emotion_history.append(emotion)
        
        cv2.imshow('Emotion Detection', frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("Quitting application...")
            break
    
    cap.release()
    cv2.destroyAllWindows()
    
    # Display emotion statistics
    print("Generating emotion statistics...")
    emotion_counts = Counter(emotion_history)
    labels, values = zip(*emotion_counts.items())
    plt.pie(values, labels=labels, autopct='%1.1f%%')
    plt.title('Emotion Distribution')
    plt.show()
    print("Emotion statistics displayed.")

if __name__ == '__main__':
    main()
